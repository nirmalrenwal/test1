package com.example.demoelasticservice.service;

import java.io.IOException;

import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoelasticservice.controller.DocumentController;
import com.example.demoelasticservice.dto.FilterProductRequestDTO;
import com.example.demoelasticservice.utility.QueryUtility;

@Service
public class DocumentService {

	private final Logger logger = LoggerFactory.getLogger(DocumentController.class);
	
	@Autowired
	private QueryUtility queryUtility;
	
	private static final String PRIMARY_UPC="primaryUpc";
	private static final String SHELF_ID="shelf.shelfId";

	@Autowired
	private RestHighLevelClient restClient;

	public SearchResponse getAllDocument() throws IOException {
		
		SearchSourceBuilder builder=new SearchSourceBuilder();
		SearchRequest req =queryUtility.getAllRequest(builder);
		SearchResponse res=null;
		
		try{
			res = restClient.search(req, RequestOptions.DEFAULT);
			return res;
		}catch(ElasticsearchException ex) {
			logger.error("Exception while Fetching data from elasticsearch");
			logger.error("{}", ex);
		}
		return res;
		
	}

	public SearchResponse filterDocument(final FilterProductRequestDTO filterProductRequestDTO) throws IOException {
		 
		
		SearchSourceBuilder builder=new SearchSourceBuilder();
		builder.query(getFilterQuery(filterProductRequestDTO));
		
		SearchRequest req =queryUtility.getAllRequest(builder);
		SearchResponse res=null;
		
		try{
			res = restClient.search(req, RequestOptions.DEFAULT);
			return res;
		}catch(ElasticsearchException ex) {
			logger.error("Exception while Fetching data from elasticsearch");
			logger.error("{}", ex);
		}
		return res;
		
	}

	public BoolQueryBuilder getFilterQuery(final FilterProductRequestDTO filterProductRequestDTO) {
		String primaryUpc = filterProductRequestDTO.getPrimaryUpc();
		String shelfId = filterProductRequestDTO.getShelfId();
	
		MatchQueryBuilder searcgByShelfId =null;
		if(shelfId!=null && shelfId!="") {
			searcgByShelfId= QueryBuilders.matchQuery(SHELF_ID, shelfId);
		}
		BoolQueryBuilder boolQueryBuilder= QueryBuilders.boolQuery()
				.must(searcgByShelfId);
		return boolQueryBuilder;
	}

}
