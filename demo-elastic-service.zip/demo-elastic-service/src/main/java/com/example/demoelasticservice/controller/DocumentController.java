package com.example.demoelasticservice.controller;

import java.io.IOException;

import org.elasticsearch.action.search.SearchResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoelasticservice.dto.FilterProductRequestDTO;
import com.example.demoelasticservice.service.DocumentService;

@RestController
@RequestMapping("products")
public class DocumentController {
	
	private final Logger logger = LoggerFactory.getLogger(DocumentController.class);
	
	@Autowired
	private DocumentService documentService;
	
	@GetMapping
	public SearchResponse getAllDocument() throws IOException {
		logger.info("Getting All documents from product Index.");
		return documentService.getAllDocument();
	}
	
	@PostMapping("filter")
	public SearchResponse filterDocument(@RequestBody FilterProductRequestDTO req
			) throws IOException {
		logger.info("Filter documents");
		return documentService.filterDocument(req);
	}

}
