package com.example.demoelasticservice.utility;

import java.util.concurrent.TimeUnit;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class QueryUtility {

	private static final long REQUEST_TIMEOUT_IN_SECONDS=60;
	
    @Value("${elasticsearch.index.name}")
	private  String INDEX;
	
	@Value("${elasticsearch.type.name}")
	private  String TYPE;
	
	
	public SearchRequest getAllRequest(SearchSourceBuilder sourceBuilder) {
		SearchRequest req=new SearchRequest(INDEX).types(TYPE);
		sourceBuilder.timeout(new TimeValue( REQUEST_TIMEOUT_IN_SECONDS, TimeUnit.SECONDS));
		req.source(sourceBuilder);
		return req;
	}
}
