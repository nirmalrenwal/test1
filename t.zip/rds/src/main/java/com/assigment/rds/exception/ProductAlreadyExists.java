package com.assigment.rds.exception;

public class ProductAlreadyExists extends RuntimeException {
	
	
	public ProductAlreadyExists(String message) {
		super(message);
	}

}
