package com.assigment.rds.dto;

import java.util.List;

import com.assigment.rds.entity.Product;

public class Catalog {
	
	List<Product> products;

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	
	

}
