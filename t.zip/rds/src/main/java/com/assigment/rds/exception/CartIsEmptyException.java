package com.assigment.rds.exception;

public class CartIsEmptyException extends RuntimeException {
	
	
	public CartIsEmptyException(String message) {
		super(message);
	}

}
