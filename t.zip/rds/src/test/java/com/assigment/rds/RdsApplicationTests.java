package com.assigment.rds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RdsApplicationTests {

	@Test
	void contextLoads() {
	}

}
