# Getting Started

Serivce is running on 8080 port and all the API are in Postman Collection. 


BasePath  : http://localhost:8080

Sample API :

http://localhost:8080/catalog/size
