package com.albertsons.elastic.constant;

import org.springframework.stereotype.Component;

@Component
public class Constants {

	public static final String INDEX 
	= "#{@environment.getProperty('elasticsearch.index.name')}";

}
