package com.albertsons.elastic.document;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

public class Aisle {

	@Field(type = FieldType.Text, fielddata = true)
	private String aisleId;
	@Field(type = FieldType.Text, fielddata = true)
	private String name;
	@Field(type = FieldType.Text, fielddata = true)
	private String urlName;
	@Field(type = FieldType.Text, fielddata = true)
	private String image;

	public String getAisleId() {
		return aisleId;
	}

	public void setAisleId(String aisleId) {
		this.aisleId = aisleId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrlName() {
		return urlName;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
}
