package com.albertsons.elastic.repository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.MultiMatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder.Order;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.web.PageableDefault;

import com.albertsons.elastic.document.Product;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProductCustomRepositoryImpl implements ProductCustomRepository {

	private final ElasticsearchTemplate elasticsearchTemplate;

	@Value("${elasticsearch.index.name}")
	private String indexName;

	@Value("${elasticsearch.agg.fieldname}")
	private List<String> aggFieldNames;

	@Autowired
	private ObjectMapper mapper;

	public ProductCustomRepositoryImpl(ElasticsearchTemplate elasticsearchTemplate) {
		this.elasticsearchTemplate = elasticsearchTemplate;
	}

	@Override
	public Object findByCustomAgg(String keyword, Pageable pageable) {

		SearchResponse response;
		MultiMatchQueryBuilder mmqb = QueryBuilders.multiMatchQuery(keyword, "*");
		SearchRequestBuilder srb = elasticsearchTemplate.getClient().prepareSearch(indexName)
				.setQuery(mmqb)
				.setSize(pageable.getPageSize())
				.setFrom(pageable.getPageSize() * pageable.getPageNumber());
		for (Sort.Order order : pageable.getSort()) {
			System.out.println(order.getDirection());
			System.out.println(order.getProperty());
			srb.addSort(SortBuilders.fieldSort(order.getProperty()).order(SortOrder.valueOf(order.getDirection().toString())));
		}
		

		for (String agg : aggFieldNames) {
			TermsAggregationBuilder aggregation = AggregationBuilders.terms(agg).field(agg).showTermDocCountError(true);
			srb.addAggregation(aggregation);
		}
		
		response = srb.execute().actionGet();
		Map<String, Object> responseMap = new HashMap();
		Map<String, List<Map<String, Object>>> map = new HashMap();
		List<Product> products = new ArrayList();

		SearchHit[] hits = response.getHits().getHits();
		for (int i = 0; i < hits.length; i++) {
			Product product = null;
			try {
				product = mapper.readValue(hits[i].getSourceAsString(), Product.class);
				products.add(product);
			} catch (IOException ex) {

			}
		}

		for (String agg : aggFieldNames) {
			Terms terms = response.getAggregations().get(agg);
			List<? extends Bucket> buckets = terms.getBuckets();
			List<Map<String, Object>> listOfMap = new ArrayList<>();
			for (Bucket bucket : buckets) {
				Map<String, Object> list = new HashMap<>();
				list.put("keyAsString", bucket.getKeyAsString());
				list.put("docCount", bucket.getDocCount());
				listOfMap.add(list);
			}
			map.put(agg, listOfMap);
		}

		responseMap.put("totalCount", response.getHits().totalHits);
		responseMap.put("products", products);
		responseMap.put("aggregation", map);
		return responseMap;
	}

}
