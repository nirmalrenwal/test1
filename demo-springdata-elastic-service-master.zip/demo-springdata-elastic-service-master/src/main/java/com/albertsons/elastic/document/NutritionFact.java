package com.albertsons.elastic.document;

public class NutritionFact {

	private Integer isOrContains;
	private Integer nutritionFactId;
	private String nutritionName;
	private Integer percentage;
	private Integer quantity;
	private String uom;
	public Integer getIsOrContains() {
		return isOrContains;
	}
	public void setIsOrContains(Integer isOrContains) {
		this.isOrContains = isOrContains;
	}
	public Integer getNutritionFactId() {
		return nutritionFactId;
	}
	public void setNutritionFactId(Integer nutritionFactId) {
		this.nutritionFactId = nutritionFactId;
	}
	public String getNutritionName() {
		return nutritionName;
	}
	public void setNutritionName(String nutritionName) {
		this.nutritionName = nutritionName;
	}
	public Integer getPercentage() {
		return percentage;
	}
	public void setPercentage(Integer percentage) {
		this.percentage = percentage;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	
}
