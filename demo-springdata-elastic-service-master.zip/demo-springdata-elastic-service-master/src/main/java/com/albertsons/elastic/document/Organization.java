package com.albertsons.elastic.document;

public class Organization {

	private String rogCd;
	private String divisionId;
	public String getRogCd() {
		return rogCd;
	}
	public void setRogCd(String rogCd) {
		this.rogCd = rogCd;
	}
	public String getDivisionId() {
		return divisionId;
	}
	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}
	
	
}
