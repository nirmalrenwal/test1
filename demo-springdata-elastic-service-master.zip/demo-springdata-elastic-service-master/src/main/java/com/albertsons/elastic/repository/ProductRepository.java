package com.albertsons.elastic.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.annotations.Query;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.albertsons.elastic.document.Product;

@Repository
@Transactional
@RepositoryRestResource(collectionResourceRel = "products", path = "products", itemResourceRel = "products")
public interface ProductRepository extends ElasticsearchRepository<Product, String> {
	
	
	//default page size=10
	//Give all results with filtered keyword output on top
	@RestResource(path = "find", rel = "find", exported = true)
	@Query("{\n"
			+ "        \"bool\": {\n"
			+ "            \"should\": [\n"
			+ "                {\n"
			+ "                    \"query_string\": {\n"
			+ "                        \"query\": \"?0\"\n"
			+ "                    }\n"
			+ "                },\n"
			+ "                {\n"
			+ "                    \"match_all\": {}\n"
			+ "                }\n"
			+ "            ]\n"
			+ "        }\n"
			+ "    }")
	List<Product> findKeywordInAllFields(@Param("q")  String q,
			Pageable pageable);


	@Query("{\"bool\": {\n"
			+ "    \"should\": [{\n"
			+ "        \"query_string\": {\n"
			+ "          \"query\": \"0?\"\n"
			+ "        } },{\n"
			+ "        \"query_string\": {\n"
			+ "          \"query\": \"?2\",\n"
			+ "          \"fields\": [\n"
			+ "            \"?1\"\n"
			+ "          ]}},\n"
			+ "      { \"match_all\": {}}]}\n"
			+ "}")
	@RestResource(path = "findboost", rel = "findboost", exported = true)
	List<Product> findKeywordAtBoostedFieldValue(@Param("q") String q, @Param("boostedField") String boostedField,
			@Param("boostedValue") String boostedValue);
	
}
