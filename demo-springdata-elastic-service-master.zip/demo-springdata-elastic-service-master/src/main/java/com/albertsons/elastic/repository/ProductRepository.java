package com.albertsons.elastic.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.albertsons.elastic.document.Product;

@Repository
@Transactional
@RepositoryRestResource(collectionResourceRel = "products", path = "products", itemResourceRel = "products")
public interface ProductRepository extends ElasticsearchRepository<Product, String>, ProductCustomRepository {
	
	
}
