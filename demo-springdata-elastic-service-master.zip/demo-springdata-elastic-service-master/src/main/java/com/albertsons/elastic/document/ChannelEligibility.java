package com.albertsons.elastic.document;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

public class ChannelEligibility {

	@Field(type = FieldType.Boolean, fielddata = true)
	private Boolean pickUp;

	@Field(type = FieldType.Boolean, fielddata = true)
	private Boolean delivery;
	public Boolean getPickUp() {
		return pickUp;
	}
	public void setPickUp(Boolean pickUp) {
		this.pickUp = pickUp;
	}
	public Boolean getDelivery() {
		return delivery;
	}
	public void setDelivery(Boolean delivery) {
		this.delivery = delivery;
	}
	
}
