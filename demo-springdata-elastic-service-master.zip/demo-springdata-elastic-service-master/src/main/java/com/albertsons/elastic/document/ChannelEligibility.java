package com.albertsons.elastic.document;

public class ChannelEligibility {

	private Boolean pickUp;
	private Boolean delivery;
	public Boolean getPickUp() {
		return pickUp;
	}
	public void setPickUp(Boolean pickUp) {
		this.pickUp = pickUp;
	}
	public Boolean getDelivery() {
		return delivery;
	}
	public void setDelivery(Boolean delivery) {
		this.delivery = delivery;
	}
	
}
