package com.albertsons.elastic.document;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

public class DetailDescription {

	@Field(type = FieldType.Text, fielddata = true)
	private String productDetails ;

	@Field(type = FieldType.Text, fielddata = true)
	private String indications ;
	@Field(type = FieldType.Text, fielddata = true)
	private String directions ;
	@Field(type = FieldType.Text, fielddata = true)
	private String ingredients ;
	@Field(type = FieldType.Text, fielddata = true)
	private String warnings ;
	@Field(type = FieldType.Text, fielddata = true)
	private String drugInteractions ;
	@Field(type = FieldType.Text, fielddata = true)
	private String vintage ;
	public String getProductDetails() {
		return productDetails;
	}
	public void setProductDetails(String productDetails) {
		this.productDetails = productDetails;
	}
	public String getIndications() {
		return indications;
	}
	public void setIndications(String indications) {
		this.indications = indications;
	}
	public String getDirections() {
		return directions;
	}
	public void setDirections(String directions) {
		this.directions = directions;
	}
	public String getIngredients() {
		return ingredients;
	}
	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}
	public String getWarnings() {
		return warnings;
	}
	public void setWarnings(String warnings) {
		this.warnings = warnings;
	}
	public String getDrugInteractions() {
		return drugInteractions;
	}
	public void setDrugInteractions(String drugInteractions) {
		this.drugInteractions = drugInteractions;
	}
	public String getVintage() {
		return vintage;
	}
	public void setVintage(String vintage) {
		this.vintage = vintage;
	}
	
}
