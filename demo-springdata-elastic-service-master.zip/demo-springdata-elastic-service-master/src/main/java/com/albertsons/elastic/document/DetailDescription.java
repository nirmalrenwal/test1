package com.albertsons.elastic.document;

public class DetailDescription {

	private String productDetails ;

	private String indications ;
	private String directions ;
	private String ingredients ;
	private String warnings ;
	private String drugInteractions ;
	private String vintage ;
	public String getProductDetails() {
		return productDetails;
	}
	public void setProductDetails(String productDetails) {
		this.productDetails = productDetails;
	}
	public String getIndications() {
		return indications;
	}
	public void setIndications(String indications) {
		this.indications = indications;
	}
	public String getDirections() {
		return directions;
	}
	public void setDirections(String directions) {
		this.directions = directions;
	}
	public String getIngredients() {
		return ingredients;
	}
	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}
	public String getWarnings() {
		return warnings;
	}
	public void setWarnings(String warnings) {
		this.warnings = warnings;
	}
	public String getDrugInteractions() {
		return drugInteractions;
	}
	public void setDrugInteractions(String drugInteractions) {
		this.drugInteractions = drugInteractions;
	}
	public String getVintage() {
		return vintage;
	}
	public void setVintage(String vintage) {
		this.vintage = vintage;
	}
	
}
