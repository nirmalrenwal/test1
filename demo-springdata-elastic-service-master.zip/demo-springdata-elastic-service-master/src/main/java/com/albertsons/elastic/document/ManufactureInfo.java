package com.albertsons.elastic.document;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

public class ManufactureInfo {

	@Field(type = FieldType.Text, fielddata = true)
	private String address;
	@Field(type = FieldType.Text, fielddata = true)
	private String copyright;
	@Field(type = FieldType.Text, fielddata = true)
	private String manufacture;
	@Field(type = FieldType.Text, fielddata = true)
	private String phone;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCopyright() {
		return copyright;
	}
	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}
	public String getManufacture() {
		return manufacture;
	}
	public void setManufacture(String manufacture) {
		this.manufacture = manufacture;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
