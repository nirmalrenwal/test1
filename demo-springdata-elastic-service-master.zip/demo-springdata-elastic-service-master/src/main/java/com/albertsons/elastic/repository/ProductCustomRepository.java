package com.albertsons.elastic.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;

public interface ProductCustomRepository {
	
	@RestResource(path = "findbycustomagg", rel = "findbycustomagg", exported = true)
    Object findByCustomAgg(@Param("q") String q,Pageable pageable);

}
