package com.albertsons.elastic.document;

public class Price {

	private String deliveryType;
	private Float price;
	private Float basePrice;
	private Float basePricePer;
	private Float pricePer;
	private String sellByWeight;
	private Integer averageWeight;
	private Integer maxWeight;
	private Float brBasePrice;
	
	public String getDeliveryType() {
		return deliveryType;
	}
	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public Float getBasePrice() {
		return basePrice;
	}
	public void setBasePrice(Float basePrice) {
		this.basePrice = basePrice;
	}
	public Float getBasePricePer() {
		return basePricePer;
	}
	public void setBasePricePer(Float basePricePer) {
		this.basePricePer = basePricePer;
	}
	public Float getPricePer() {
		return pricePer;
	}
	public void setPricePer(Float pricePer) {
		this.pricePer = pricePer;
	}
	public String getSellByWeight() {
		return sellByWeight;
	}
	public void setSellByWeight(String sellByWeight) {
		this.sellByWeight = sellByWeight;
	}
	public Integer getAverageWeight() {
		return averageWeight;
	}
	public void setAverageWeight(Integer averageWeight) {
		this.averageWeight = averageWeight;
	}
	public Integer getMaxWeight() {
		return maxWeight;
	}
	public void setMaxWeight(Integer maxWeight) {
		this.maxWeight = maxWeight;
	}
	public Float getBrBasePrice() {
		return brBasePrice;
	}
	public void setBrBasePrice(Float brBasePrice) {
		this.brBasePrice = brBasePrice;
	}
	
}