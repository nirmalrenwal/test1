package com.albertsons.elastic.document;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

public class Price {

	@Field(type = FieldType.Text, fielddata = true)
	private String deliveryType;
	@Field(type = FieldType.Float, fielddata = true)
	private Float price;
	@Field(type = FieldType.Float, fielddata = true)
	private Float basePrice;
	@Field(type = FieldType.Float, fielddata = true)
	private Float basePricePer;
	@Field(type = FieldType.Float, fielddata = true)
	private Float pricePer;
	@Field(type = FieldType.Text, fielddata = true)
	private String sellByWeight;
	@Field(type = FieldType.Integer, fielddata = true)
	private Integer averageWeight;
	@Field(type = FieldType.Integer, fielddata = true)
	private Integer maxWeight;
	@Field(type = FieldType.Float, fielddata = true)
	private Float brBasePrice;
	
	public String getDeliveryType() {
		return deliveryType;
	}
	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public Float getBasePrice() {
		return basePrice;
	}
	public void setBasePrice(Float basePrice) {
		this.basePrice = basePrice;
	}
	public Float getBasePricePer() {
		return basePricePer;
	}
	public void setBasePricePer(Float basePricePer) {
		this.basePricePer = basePricePer;
	}
	public Float getPricePer() {
		return pricePer;
	}
	public void setPricePer(Float pricePer) {
		this.pricePer = pricePer;
	}
	public String getSellByWeight() {
		return sellByWeight;
	}
	public void setSellByWeight(String sellByWeight) {
		this.sellByWeight = sellByWeight;
	}
	public Integer getAverageWeight() {
		return averageWeight;
	}
	public void setAverageWeight(Integer averageWeight) {
		this.averageWeight = averageWeight;
	}
	public Integer getMaxWeight() {
		return maxWeight;
	}
	public void setMaxWeight(Integer maxWeight) {
		this.maxWeight = maxWeight;
	}
	public Float getBrBasePrice() {
		return brBasePrice;
	}
	public void setBrBasePrice(Float brBasePrice) {
		this.brBasePrice = brBasePrice;
	}
	
}