package com.albertsons.elastic.document;

public class ItemHierarchy {

	private String groupDesc;
	private String catDesc;
	private String smicDesc;
	private String classDesc;
	private String subClassDesc1;
	private String subClassDesc2;
	private String groupCd;
	private String categoryCd;
	private String classCd;
	private String subClassCd1;
	private String subClassCd2;
	public String getGroupDesc() {
		return groupDesc;
	}
	public void setGroupDesc(String groupDesc) {
		this.groupDesc = groupDesc;
	}
	public String getCatDesc() {
		return catDesc;
	}
	public void setCatDesc(String catDesc) {
		this.catDesc = catDesc;
	}
	public String getSmicDesc() {
		return smicDesc;
	}
	public void setSmicDesc(String smicDesc) {
		this.smicDesc = smicDesc;
	}
	public String getClassDesc() {
		return classDesc;
	}
	public void setClassDesc(String classDesc) {
		this.classDesc = classDesc;
	}
	public String getSubClassDesc1() {
		return subClassDesc1;
	}
	public void setSubClassDesc1(String subClassDesc1) {
		this.subClassDesc1 = subClassDesc1;
	}
	public String getSubClassDesc2() {
		return subClassDesc2;
	}
	public void setSubClassDesc2(String subClassDesc2) {
		this.subClassDesc2 = subClassDesc2;
	}
	public String getGroupCd() {
		return groupCd;
	}
	public void setGroupCd(String groupCd) {
		this.groupCd = groupCd;
	}
	public String getCategoryCd() {
		return categoryCd;
	}
	public void setCategoryCd(String categoryCd) {
		this.categoryCd = categoryCd;
	}
	public String getClassCd() {
		return classCd;
	}
	public void setClassCd(String classCd) {
		this.classCd = classCd;
	}
	public String getSubClassCd1() {
		return subClassCd1;
	}
	public void setSubClassCd1(String subClassCd1) {
		this.subClassCd1 = subClassCd1;
	}
	public String getSubClassCd2() {
		return subClassCd2;
	}
	public void setSubClassCd2(String subClassCd2) {
		this.subClassCd2 = subClassCd2;
	}

}
