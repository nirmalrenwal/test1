package com.albertsons.elastic.document;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

public class ItemHierarchy {

	@Field(type = FieldType.Text, fielddata = true)
	private String groupDesc;
	@Field(type = FieldType.Text, fielddata = true)
	private String catDesc;
	@Field(type = FieldType.Text, fielddata = true)
	private String smicDesc;
	@Field(type = FieldType.Text, fielddata = true)
	private String classDesc;
	@Field(type = FieldType.Text, fielddata = true)
	private String subClassDesc1;
	@Field(type = FieldType.Text, fielddata = true)
	private String subClassDesc2;
	@Field(type = FieldType.Text, fielddata = true)
	private String groupCd;
	@Field(type = FieldType.Text, fielddata = true)
	private String categoryCd;
	@Field(type = FieldType.Text, fielddata = true)
	private String classCd;
	@Field(type = FieldType.Text, fielddata = true)
	private String subClassCd1;
	@Field(type = FieldType.Text, fielddata = true)
	private String subClassCd2;
	public String getGroupDesc() {
		return groupDesc;
	}
	public void setGroupDesc(String groupDesc) {
		this.groupDesc = groupDesc;
	}
	public String getCatDesc() {
		return catDesc;
	}
	public void setCatDesc(String catDesc) {
		this.catDesc = catDesc;
	}
	public String getSmicDesc() {
		return smicDesc;
	}
	public void setSmicDesc(String smicDesc) {
		this.smicDesc = smicDesc;
	}
	public String getClassDesc() {
		return classDesc;
	}
	public void setClassDesc(String classDesc) {
		this.classDesc = classDesc;
	}
	public String getSubClassDesc1() {
		return subClassDesc1;
	}
	public void setSubClassDesc1(String subClassDesc1) {
		this.subClassDesc1 = subClassDesc1;
	}
	public String getSubClassDesc2() {
		return subClassDesc2;
	}
	public void setSubClassDesc2(String subClassDesc2) {
		this.subClassDesc2 = subClassDesc2;
	}
	public String getGroupCd() {
		return groupCd;
	}
	public void setGroupCd(String groupCd) {
		this.groupCd = groupCd;
	}
	public String getCategoryCd() {
		return categoryCd;
	}
	public void setCategoryCd(String categoryCd) {
		this.categoryCd = categoryCd;
	}
	public String getClassCd() {
		return classCd;
	}
	public void setClassCd(String classCd) {
		this.classCd = classCd;
	}
	public String getSubClassCd1() {
		return subClassCd1;
	}
	public void setSubClassCd1(String subClassCd1) {
		this.subClassCd1 = subClassCd1;
	}
	public String getSubClassCd2() {
		return subClassCd2;
	}
	public void setSubClassCd2(String subClassCd2) {
		this.subClassCd2 = subClassCd2;
	}

}
