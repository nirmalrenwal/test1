package com.albertsons.elastic.document;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
import org.springframework.data.elasticsearch.annotations.MultiField;

import com.albertsons.elastic.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@Document(indexName = Constants.INDEX)
public class Product implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String id;

	private String primaryUpc;
	private String storeId;
	
	private String bpnId;
	private String status;
	private String inventoryAvailable;
	private String imageUrl;
	private String name;
	private String brand;
	private Integer salesRank;
	private String enrichmentDesc;
	private String zonecode;
	private Integer itemAvgWeight;
	private String batchId;

	private Integer displayType; //-1
	private Integer brRestrictedDepartmentOverride;
	private String itemRetailSect;
	private String pointsApply; //Y
	private String itemSizeQty; ///1.0
	private String discountYN;
	

	private String itemPriceLookUpCd;
	@JsonProperty("WICItemInd")
	private String WICItemInd;
	private String itemPackageQty;
	private String itemPackageWeight;
	private Integer restrictedDepartmentOverride;
	private Integer maxPurchaseQty;
	private String unitOfMeasure;
	private String smicCd;
	private String unitQuantity;
	private String snapEligible; //true
	
	private ChannelEligibility channelEligibility;
	private ItemHierarchy itemHierarchy;
	//private Prop prop65;
	private Organization organization;
	private DetailDescription detailDescription;
	private ManufactureInfo manufactureInfo;
	private Dimension dimension;

	private List<NutritionFact> nutritionFacts;
	private List<ServingDetail> servingDetails;
	private List<String> cic;
	private List<Price> prices;

	
	
	
	@MultiField(mainField = 
    		@Field(type = FieldType.Text, fielddata = true)) 
	private Department department;
	
    @MultiField(mainField = 
    		@Field(type = FieldType.Text, fielddata = true)) 
	private Aisle aisle;
   
    @MultiField(mainField = 
    		@Field(type = FieldType.Text, fielddata = true)) 
    private Shelf shelf;
    
	public String getPrimaryUpc() {
		return primaryUpc;
	}
	public void setPrimaryUpc(String primaryUpc) {
		this.primaryUpc = primaryUpc;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Aisle getAisle() {
		return aisle;
	}
	public void setAisle(Aisle aisle) {
		this.aisle = aisle;
	}
	public Shelf getShelf() {
		return shelf;
	}
	public void setShelf(Shelf shelf) {
		this.shelf = shelf;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getBpnId() {
		return bpnId;
	}
	public void setBpnId(String bpnId) {
		this.bpnId = bpnId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInventoryAvailable() {
		return inventoryAvailable;
	}
	public void setInventoryAvailable(String inventoryAvailable) {
		this.inventoryAvailable = inventoryAvailable;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Integer getSalesRank() {
		return salesRank;
	}
	public void setSalesRank(Integer salesRank) {
		this.salesRank = salesRank;
	}
	public String getEnrichmentDesc() {
		return enrichmentDesc;
	}
	public void setEnrichmentDesc(String enrichmentDesc) {
		this.enrichmentDesc = enrichmentDesc;
	}
	public String getZonecode() {
		return zonecode;
	}
	public void setZonecode(String zonecode) {
		this.zonecode = zonecode;
	}
	public Integer getItemAvgWeight() {
		return itemAvgWeight;
	}
	public void setItemAvgWeight(Integer itemAvgWeight) {
		this.itemAvgWeight = itemAvgWeight;
	}
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public Integer getDisplayType() {
		return displayType;
	}
	public void setDisplayType(Integer displayType) {
		this.displayType = displayType;
	}
	public Integer getBrRestrictedDepartmentOverride() {
		return brRestrictedDepartmentOverride;
	}
	public void setBrRestrictedDepartmentOverride(Integer brRestrictedDepartmentOverride) {
		this.brRestrictedDepartmentOverride = brRestrictedDepartmentOverride;
	}
	public String getItemRetailSect() {
		return itemRetailSect;
	}
	public void setItemRetailSect(String itemRetailSect) {
		this.itemRetailSect = itemRetailSect;
	}
	public String getPointsApply() {
		return pointsApply;
	}
	public void setPointsApply(String pointsApply) {
		this.pointsApply = pointsApply;
	}
	public String getItemSizeQty() {
		return itemSizeQty;
	}
	public void setItemSizeQty(String itemSizeQty) {
		this.itemSizeQty = itemSizeQty;
	}
	public String getDiscountYN() {
		return discountYN;
	}
	public void setDiscountYN(String discountYN) {
		this.discountYN = discountYN;
	}
	public String getItemPriceLookUpCd() {
		return itemPriceLookUpCd;
	}
	public void setItemPriceLookUpCd(String itemPriceLookUpCd) {
		this.itemPriceLookUpCd = itemPriceLookUpCd;
	}
	public String getWICItemInd() {
		return WICItemInd;
	}
	public void setWICItemInd(String wICItemInd) {
		WICItemInd = wICItemInd;
	}
	public String getItemPackageQty() {
		return itemPackageQty;
	}
	public void setItemPackageQty(String itemPackageQty) {
		this.itemPackageQty = itemPackageQty;
	}
	public String getItemPackageWeight() {
		return itemPackageWeight;
	}
	public void setItemPackageWeight(String itemPackageWeight) {
		this.itemPackageWeight = itemPackageWeight;
	}
	public Integer getRestrictedDepartmentOverride() {
		return restrictedDepartmentOverride;
	}
	public void setRestrictedDepartmentOverride(Integer restrictedDepartmentOverride) {
		this.restrictedDepartmentOverride = restrictedDepartmentOverride;
	}
	public Integer getMaxPurchaseQty() {
		return maxPurchaseQty;
	}
	public void setMaxPurchaseQty(Integer maxPurchaseQty) {
		this.maxPurchaseQty = maxPurchaseQty;
	}
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}
	public String getSmicCd() {
		return smicCd;
	}
	public void setSmicCd(String smicCd) {
		this.smicCd = smicCd;
	}
	public String getSnapEligible() {
		return snapEligible;
	}
	public void setSnapEligible(String snapEligible) {
		this.snapEligible = snapEligible;
	}
	public ChannelEligibility getChannelEligibility() {
		return channelEligibility;
	}
	public void setChannelEligibility(ChannelEligibility channelEligibility) {
		this.channelEligibility = channelEligibility;
	}
	public ItemHierarchy getItemHierarchy() {
		return itemHierarchy;
	}
	public void setItemHierarchy(ItemHierarchy itemHierarchy) {
		this.itemHierarchy = itemHierarchy;
	}
	public Organization getOrganization() {
		return organization;
	}
	public void setOrganization(Organization organization) {
		this.organization = organization;
	}
	public DetailDescription getDetailDescription() {
		return detailDescription;
	}
	public void setDetailDescription(DetailDescription detailDescription) {
		this.detailDescription = detailDescription;
	}
	public ManufactureInfo getManufactureInfo() {
		return manufactureInfo;
	}
	public void setManufactureInfo(ManufactureInfo manufactureInfo) {
		this.manufactureInfo = manufactureInfo;
	}
	public Dimension getDimension() {
		return dimension;
	}
	public void setDimension(Dimension dimension) {
		this.dimension = dimension;
	}
	public List<NutritionFact> getNutritionFacts() {
		return nutritionFacts;
	}
	public void setNutritionFacts(List<NutritionFact> nutritionFacts) {
		this.nutritionFacts = nutritionFacts;
	}
	public List<ServingDetail> getServingDetails() {
		return servingDetails;
	}
	public void setServingDetails(List<ServingDetail> servingDetails) {
		this.servingDetails = servingDetails;
	}
	public List<String> getCic() {
		return cic;
	}
	public void setCic(List<String> cic) {
		this.cic = cic;
	}
	public List<Price> getPrices() {
		return prices;
	}
	public void setPrices(List<Price> prices) {
		this.prices = prices;
	}
	public String getUnitQuantity() {
		return unitQuantity;
	}
	public void setUnitQuantity(String unitQuantity) {
		this.unitQuantity = unitQuantity;
	}
}