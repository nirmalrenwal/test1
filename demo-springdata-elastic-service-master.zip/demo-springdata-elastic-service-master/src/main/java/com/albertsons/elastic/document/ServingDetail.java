package com.albertsons.elastic.document;

public class ServingDetail {
	
	private String addedItem;
	private String servingSizeText;
	private String servingSizeUOM;
	private String servingsPerContainer;
	public String getAddedItem() {
		return addedItem;
	}
	public void setAddedItem(String addedItem) {
		this.addedItem = addedItem;
	}
	public String getServingSizeText() {
		return servingSizeText;
	}
	public void setServingSizeText(String servingSizeText) {
		this.servingSizeText = servingSizeText;
	}
	public String getServingSizeUOM() {
		return servingSizeUOM;
	}
	public void setServingSizeUOM(String servingSizeUOM) {
		this.servingSizeUOM = servingSizeUOM;
	}
	public String getServingsPerContainer() {
		return servingsPerContainer;
	}
	public void setServingsPerContainer(String servingsPerContainer) {
		this.servingsPerContainer = servingsPerContainer;
	}
}
