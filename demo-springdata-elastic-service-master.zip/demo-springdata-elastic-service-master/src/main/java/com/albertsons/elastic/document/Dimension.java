package com.albertsons.elastic.document;

public class Dimension {
	
	private Float width;
	private Float depth;
	private Float height;
	public Float getWidth() {
		return width;
	}
	public void setWidth(Float width) {
		this.width = width;
	}
	public Float getDepth() {
		return depth;
	}
	public void setDepth(Float depth) {
		this.depth = depth;
	}
	public Float getHeight() {
		return height;
	}
	public void setHeight(Float height) {
		this.height = height;
	}
	

}
