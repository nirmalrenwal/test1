package com.albertsons.elastic.document;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

public class Dimension {

	@Field(type = FieldType.Float, fielddata = true)
	private Float width;
	@Field(type = FieldType.Float, fielddata = true)
	private Float depth;
	@Field(type = FieldType.Float, fielddata = true)
	private Float height;
	public Float getWidth() {
		return width;
	}
	public void setWidth(Float width) {
		this.width = width;
	}
	public Float getDepth() {
		return depth;
	}
	public void setDepth(Float depth) {
		this.depth = depth;
	}
	public Float getHeight() {
		return height;
	}
	public void setHeight(Float height) {
		this.height = height;
	}
	

}
