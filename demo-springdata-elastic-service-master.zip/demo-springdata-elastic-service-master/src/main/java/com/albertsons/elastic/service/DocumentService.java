package com.albertsons.elastic.service;

import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DocumentService {

	private final Logger logger = LoggerFactory.getLogger(DocumentService.class);
	
	@Autowired
	private RestHighLevelClient restHighLevelClient;
	
}
