package com.example.demoelasticservice.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.annotations.Query;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demoelasticservice.document.Product;

@Repository
@Transactional
@RepositoryRestResource(collectionResourceRel = "products", path = "products", itemResourceRel = "products")
public interface ProductRepository extends ElasticsearchRepository<Product, String> {
	
	//shelf.name : passed param search, only filtered output
	@RestResource(path = "findbycustomquery", rel = "findbycustomquery", exported = true)
	@Query("{\n"
			+ "    \"multi_match\": {\n"
			+ "      \"query\": \"?0\",\n"
			+ "      \"fields\": [\n"
			+ "        \"shelf.name\"\n"
			+ "      ],\n"
			+ "      \"type\": \"best_fields\",\n"
			+ "      \"operator\": \"OR\",\n"
			+ "      \"slop\": 0,\n"
			+ "      \"prefix_length\": 0,\n"
			+ "      \"max_expansions\": 50,\n"
			+ "      \"zero_terms_query\": \"NONE\",\n"
			+ "      \"auto_generate_synonyms_phrase_query\": true,\n"
			+ "      \"fuzzy_transpositions\": true,\n"
			+ "      \"boost\": 1\n"
			+ "    }\n"
			+ "  }")
	List<Product> findByCustomQuery(@Param("q")  String q);

	//field and keyword both will take from user:, only filtered output
	@RestResource(path = "findbyfieldandvalue", rel = "findbyfieldandvalue", exported = true)
	@Query("{\n"
			+ "    \"multi_match\": {\n"
			+ "      \"query\": \"?0\",\n"
			+ "      \"fields\": [\n"
			+ "        \"?1\" \n"
			+ "      ],\n"
			+ "      \"type\": \"best_fields\",\n"
			+ "      \"operator\": \"OR\",\n"
			+ "      \"slop\": 0,\n"
			+ "      \"prefix_length\": 0,\n"
			+ "      \"max_expansions\": 50,\n"
			+ "      \"zero_terms_query\": \"NONE\",\n"
			+ "      \"auto_generate_synonyms_phrase_query\": true,\n"
			+ "      \"fuzzy_transpositions\": true,\n"
			+ "      \"boost\": 1\n"
			+ "    }\n"
			+ "  }")
	List<Product> findByCustomQuery(@Param("q")  String q, @Param("field")  String field);

	//default page size=10
	//Give all results with filtered keyword output on top
	@RestResource(path = "findkeywordinallfields", rel = "findkeywordinallfields", exported = true)
	@Query("{\n"
			+ "        \"bool\": {\n"
			+ "            \"should\": [\n"
			+ "                {\n"
			+ "                    \"query_string\": {\n"
			+ "                        \"query\": \"?0\"\n"
			+ "                    }\n"
			+ "                },\n"
			+ "                {\n"
			+ "                    \"match_all\": {}\n"
			+ "                }\n"
			+ "            ]\n"
			+ "        }\n"
			+ "    }")
	List<Product> findKeywordInAllFields(@Param("q")  String q,
			Pageable pageable);
	
	
	//fields boosted with search keyword: all result
	@RestResource(path = "findkeywordinallfieldsboosted", rel = "findkeywordinallfieldsboosted", exported = true)
	@Query("{\n"
			+ "    \"bool\": {\n"
			+ "      \"should\": [\n"
			+ "        {\n"
			+ "          \"query_string\": {\n"
			+ "            \"query\": \"?0\",\n"
			+ "            \"fields\": [\n"
			+ "              \"shelf.name^5\",\n"
			+ "              \"department.name\"\n"
			+ "            ]\n"
			+ "          }\n"
			+ "        },\n"
			+ "        {\n"
			+ "          \"match_all\": {}\n"
			+ "        }\n"
			+ "      ]\n"
			+ "    }\n"
			+ "  }")
	List<Product> findKeywordInAllBoostedFields(@Param("q")  String q,
			Pageable pageable);
	

	//input: boosted field : with search keyword: all result
	@RestResource(path = "findkeywordinallboostedparam", rel = "findkeywordinallboostedparam", exported = true)
	@Query("{\n"
			+ "    \"bool\": {\n"
			+ "      \"should\": [\n"
			+ "        {\n"
			+ "          \"query_string\": {\n"
			+ "            \"query\": \"?0\",\n"
			+ "            \"fields\": [\n"
			+ "              \"?1\"\n"
			+ "            ]\n"
			+ "          }\n"
			+ "        },\n"
			+ "        {\n"
			+ "          \"match_all\": {}\n"
			+ "        }\n"
			+ "      ]\n"
			+ "    }\n"
			+ "  }")
	List<Product> findKeywordInAllBoostedparam(@Param("q")  String q,
			@Param("boosted")  String boosted,
			Pageable pageable);
	

	//findAll
	@RestResource(path = "findall", rel = "findall", exported = true)
	List<Product> findAll();
	
	@Query("{\n"
			+ "    \"agg\": {\n"
			+ "        \"shelf.name.keyword\": {\n"
			+ "            \"terms\": {\n"
			+ "                \"field\": \"?0\"\n"
			+ "            }\n"
			+ "        }\n"
			+ "    }\n"
			+ "}")
	@RestResource(path = "findaggregation", rel = "findaggregation", exported = true)
	List<Product> findAggregation(@Param("agg")  String agg);
	
	
}
