package com.example.demoelasticservice.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FilterProductRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String primaryUpc;
	private String shelfId;
	
	private Integer size;
	

	public String getPrimaryUpc() {
		return primaryUpc;
	}

	public void setPrimaryUpc(String primaryUpc) {
		this.primaryUpc = primaryUpc;
	}

	public String getShelfId() {
		return shelfId;
	}

	public void setShelfId(String shelfId) {
		this.shelfId = shelfId;
	}

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}
	
	
}
