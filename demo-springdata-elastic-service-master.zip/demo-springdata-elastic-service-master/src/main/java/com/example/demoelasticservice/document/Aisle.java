package com.example.demoelasticservice.document;

public class Aisle {

	private String aisleId;

	private String name;

	public String getAisleId() {
		return aisleId;
	}

	public void setAisleId(String aisleId) {
		this.aisleId = aisleId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
