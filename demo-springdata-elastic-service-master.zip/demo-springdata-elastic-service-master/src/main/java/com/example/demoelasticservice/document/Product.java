package com.example.demoelasticservice.document;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
import org.springframework.data.elasticsearch.annotations.MultiField;

@Document(indexName = "product", type="_doc")
public class Product implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	private String primaryUpc;
	private Integer price;
	
	@MultiField(mainField = 
    		@Field(type = FieldType.Text, fielddata = true)) 
	private Department department;
	
    @MultiField(mainField = 
    		@Field(type = FieldType.Text, fielddata = true)) 
	private Aisle aisle;
   
    @MultiField(mainField = 
    		@Field(type = FieldType.Text, fielddata = true)) 
    private Shelf shelf;
    
	public String getPrimaryUpc() {
		return primaryUpc;
	}
	public void setPrimaryUpc(String primaryUpc) {
		this.primaryUpc = primaryUpc;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Aisle getAisle() {
		return aisle;
	}
	public void setAisle(Aisle aisle) {
		this.aisle = aisle;
	}
	public Shelf getShelf() {
		return shelf;
	}
	public void setShelf(Shelf shelf) {
		this.shelf = shelf;
	}
}
