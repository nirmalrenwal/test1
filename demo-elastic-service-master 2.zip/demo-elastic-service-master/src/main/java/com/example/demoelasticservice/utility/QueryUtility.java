package com.example.demoelasticservice.utility;

import java.util.concurrent.TimeUnit;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.example.demoelasticservice.dto.FilterRequest;

@Component
public class QueryUtility {

	private static final long REQUEST_TIMEOUT_IN_SECONDS = 60;

	@Value("${elasticsearch.index.name}")
	private String INDEX;

	@Value("${elasticsearch.type.name}")
	private String TYPE;

	public SearchRequest getAllRequest(SearchSourceBuilder sourceBuilder, Integer size) {
		SearchRequest req = new SearchRequest(INDEX).types(TYPE);
		sourceBuilder.timeout(new TimeValue(REQUEST_TIMEOUT_IN_SECONDS, TimeUnit.SECONDS));
		sourceBuilder.size(size);
		req.source(sourceBuilder);
		return req;
	}

	public SearchRequest filterProductlRequest(SearchSourceBuilder sourceBuilder, 
			final FilterRequest req, final Integer size) {
		SearchRequest searchRequest = new SearchRequest(INDEX).types(TYPE);
		sourceBuilder.timeout(new TimeValue(REQUEST_TIMEOUT_IN_SECONDS, TimeUnit.SECONDS));

		if (req.getAggfields() != null)
			for (String agg : req.getAggfields()) {
				TermsAggregationBuilder aggregation = AggregationBuilders.terms(agg).field(agg)
						.size(req.getSize());
				sourceBuilder.aggregation(aggregation);
			}
		searchRequest.source(sourceBuilder);
		sourceBuilder.from(0);
		sourceBuilder.size(size);

		return searchRequest;
	}

}
