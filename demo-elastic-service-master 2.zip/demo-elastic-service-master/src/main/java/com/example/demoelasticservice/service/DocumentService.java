package com.example.demoelasticservice.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.Operator;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoelasticservice.controller.DocumentController;
import com.example.demoelasticservice.dto.FilterRequest;
import com.example.demoelasticservice.utility.QueryUtility;

@Service
public class DocumentService {

	private final Logger logger = LoggerFactory.getLogger(DocumentController.class);
	
	@Autowired
	private QueryUtility queryUtility;
	
	@Autowired
	private RestHighLevelClient restHighLevelClient;
	

	public SearchResponse getAllDocument(final Integer size) throws IOException {
		
		SearchSourceBuilder builder=new SearchSourceBuilder();
		SearchRequest req =queryUtility.getAllRequest(builder, size);
		SearchResponse res=null;
		
		try{
			res = restHighLevelClient.search(req, RequestOptions.DEFAULT);
			return res;
		}catch(ElasticsearchException ex) {
			logger.error("Exception while Fetching data from elasticsearch");
			logger.error("{}", ex);
		}
		return res;
		
	}

	public Map<String, List<Map<String, Object>>> filterProduct(final FilterRequest req,
			final Integer size) throws IOException {
		SearchSourceBuilder builder=new SearchSourceBuilder();
		builder.query(filterQuery(req));
		
		SearchRequest searchRequest =queryUtility.filterProductlRequest(builder, req, size);
		SearchResponse res=null;
		
		try{
			res = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
			Map<String, List<Map<String, Object>>> map=new HashMap();
			
			for(String agg: req.getAggfields()) {
				Terms  terms = res.getAggregations().get(agg);
				List<? extends Bucket> buckets=terms.getBuckets();
				List<Map<String, Object>> listOfMap=new ArrayList<>();
				for(Bucket bucket: buckets) {
					Map<String, Object> list=new HashMap<>();
					list.put("keyAsString", bucket.getKeyAsString());
					list.put("docCount", bucket.getDocCount());
					listOfMap.add(list);
				}				
				map.put(agg, listOfMap);
			}
			return map;
		}catch(ElasticsearchException ex) {
			logger.error("Exception while Fetching data from elasticsearch");
			logger.error("{}", ex);
		}
		return null;
	}
	
	public BoolQueryBuilder filterQuery(final FilterRequest req) {
		
		MatchQueryBuilder search =null;
		BoolQueryBuilder boolQueryBuilder= QueryBuilders.boolQuery();
		for(String field: req.getFields()) {
			search=null;
			search=QueryBuilders.matchQuery(field, req.getQuery());
			boolQueryBuilder=boolQueryBuilder.must(search);
		}
		return boolQueryBuilder;
	}
	
	public SearchResponse getProductByKeywordBoost(final String keyword,
			Optional<FilterRequest> optionalReq,
			Integer size) throws IOException {
		
		List<String> boostedFields=new ArrayList<>();
		if(optionalReq.isPresent()) {
			boostedFields=optionalReq.get().getFields();
		}
		SearchSourceBuilder builder=new SearchSourceBuilder();
		builder.query(getProductByKeywordQueryBoost(keyword, boostedFields));
		SearchRequest req =queryUtility.getAllRequest(builder, size);
		SearchResponse res=null;
		
		try{
			res = restHighLevelClient.search(req, RequestOptions.DEFAULT);
			return res;
		}catch(ElasticsearchException ex) {
			logger.error("Exception while Fetching data from elasticsearch");
			logger.error("{}", ex);
		}
		return res;
		
	}
	
	public QueryBuilder getProductByKeywordQueryBoost(final String keyword,
			List<String> boostedFields) {
		QueryBuilder query = new BoolQueryBuilder().must(
				QueryBuilders.multiMatchQuery(keyword, boostedFields.toArray(new String[0])).operator(Operator.AND));
		return query;
	}

}
