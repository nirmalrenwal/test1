package com.example.demoelasticservice.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoelasticservice.dto.FilterRequest;
import com.example.demoelasticservice.service.DocumentService;

@RestController
@RequestMapping("products")
public class DocumentController {

	private final Logger logger = LoggerFactory.getLogger(DocumentController.class);

	@Autowired
	private DocumentService documentService;

	@GetMapping
	public SearchResponse getAllDocument(@RequestParam(required = false, defaultValue = "10") Integer size)
			throws IOException {
		logger.info("Getting All documents from product Index.");
		return documentService.getAllDocument(size);
	}

	@PostMapping("multi/filter")
	public Map<String, List<Map<String, Object>>> filterProduct(@RequestBody FilterRequest req,
			@RequestParam(required = false, defaultValue = "10") Integer size) throws IOException {
		logger.info("Filter Products");
		return documentService.filterProduct(req, size);
	}

	@PostMapping("search/boost")
	public SearchResponse getProductByKeywordBoost(@RequestParam(name = "q") String keyword,
			@RequestParam(required = false, defaultValue = "10") Integer size, @RequestBody Optional<FilterRequest> req)
			throws IOException {
		logger.info("Getting All documents from product Index.");
		return documentService.getProductByKeywordBoost(keyword, req, size);
	}

}
