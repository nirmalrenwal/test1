package com.example.demoelasticservice.dto;

import java.io.Serializable;
import java.util.List;

public class FilterRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String query;
	private List<String> fields;
	private List<String> aggfields;
	private Integer size;
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public List<String> getFields() {
		return fields;
	}
	public void setFields(List<String> fields) {
		this.fields = fields;
	}
	public List<String> getAggfields() {
		return aggfields;
	}
	public void setAggfields(List<String> aggfields) {
		this.aggfields = aggfields;
	}
	public Integer getSize() {
		return size;
	}
	public void setSize(Integer size) {
		this.size = size;
	}
	
}
